using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR; // For XR-related features
using UnityEngine.XR.Management; // For XR management


public class Menu : MonoBehaviour
{
    public GameObject[] watches;
    private int currentwatch = 0;

    public void NextWatch()
    {
        if (watches == null || watches.Length == 0)
        {
            Debug.LogWarning("Watches array is empty!");
            return;
        }

        watches[currentwatch].gameObject.SetActive(false); // Deactivate current watch
        currentwatch = (currentwatch + 1) % watches.Length; // Increment and wrap around
        watches[currentwatch].gameObject.SetActive(true);  // Activate new watch
    }

    public void PrevWatch()
    {
        if (watches == null || watches.Length == 0)
        {
            Debug.LogWarning("Watches array is empty!");
            return;
        }

        watches[currentwatch].gameObject.SetActive(false); // Deactivate current watch
        currentwatch = (currentwatch - 1 + watches.Length) % watches.Length; // Decrement and wrap around
        watches[currentwatch].gameObject.SetActive(true);  // Activate new watch
    }
}
